# bassmodel
Package to simulate and fit the Bass model with generations
