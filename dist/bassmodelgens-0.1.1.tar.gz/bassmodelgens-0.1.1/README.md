# bassmodelgens
Package containing functions to simulate the Bass diffusion model with generations (1987) and fit it to data.
